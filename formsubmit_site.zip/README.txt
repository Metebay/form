
Bu proje FormSubmit kullanarak çalışan bir iletişim formu içerir.

Kullanım:
1. index.html dosyasını bir tarayıcıda açın.
2. Formu doldurup gönderin.
3. Başarılı gönderimden sonra tesekkurler.html sayfasına yönlendirilirsiniz.

Not:
- E-posta adresinizin doğru olduğundan ve FormSubmit'ten gelen onay e-postasını onayladığınızdan emin olun.
- Yerel sunucuda çalıştırmak istersen: terminalde python3 -m http.server komutunu kullanın.
